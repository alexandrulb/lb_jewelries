# luxurybazaar_jewelry

Blocks: **LBJ - Hero** (`lb-jewelry/hero`), **LBJ - Carousel** (`lb-jewelry/carousel`).

## Build
```bash
npm install
npm run build
```

## Notes
- Block names are hyphenated (`lb-jewelry/hero`, `lb-jewelry/carousel`) per Gutenberg rules.
